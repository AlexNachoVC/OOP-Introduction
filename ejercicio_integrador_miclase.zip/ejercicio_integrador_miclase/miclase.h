#ifndef MICLASE_H
#define MICLASE_H

class MiClase {
    int var1;
public:
    MiClase(); // Constructor por defecto
    void setVar1(int value); // Método para establecer var1
    int getVar1(); // Método para obtener var1
    
};

#endif